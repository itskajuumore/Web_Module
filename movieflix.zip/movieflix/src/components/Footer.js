import React from "react";

const Footer = () => {
  return (
    <div className="footer bg-danger bg-gradient">
      <h5>&copy; All right reserved to MovieFlix</h5>
    </div>
  );
};

export default Footer;
