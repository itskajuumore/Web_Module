import React from "react";
import { createBrowserRouter } from "react-router-dom";
import App from "./App";
import Popularmovies from "./components/Popularmovies";
import TopRatedmovies from "./components/TopRatedmovies";
import Upcomingmovies from "./components/Upcomingmovies";
import Search from "./components/Search";
import movieDetails from "./components/MovieDetails";

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      {
        path: "/pop",
        element: <Popularmovies />,
      },

      {
        path: "/Topratedmovies",
        element: <TopRatedmovies />,
      },

      {
        path: "/Upcomingmovies",
        element: <Upcomingmovies />,
      },

      {
        path: "/Search",
        element: <Search />,
      },

      {
        path: "/Movie",
        element: <movieDetails />,
      },
    ],
  },
]);

export default router;
